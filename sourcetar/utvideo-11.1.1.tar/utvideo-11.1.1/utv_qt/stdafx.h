/*  */
/* $Id: stdafx.h 738 2011-09-03 10:22:57Z umezawa $ */

#include <Carbon/Carbon.h>
#include <QuickTime/QuickTime.h>
